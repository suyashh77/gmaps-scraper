"""
Headed Google login helper: creates a new auth/google_auth_N.json session.

    python make_auth.py

Opens a real (visible) browser at accounts.google.com. Log in by hand — 2FA,
"Verify it's you" prompts, all of it — then come back to this terminal and
press Enter. The session is saved only if Google Maps then shows a signed-in
page rather than "Sign in"; a login that got interrupted or bounced back to
a challenge screen is not silently saved as if it had worked.
"""
from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path

from linux_scraper.config import load_config
from linux_scraper.scraper import GoogleMapsScraper

HERE = Path(__file__).resolve().parent
AUTH_DIR = HERE / "auth"


def _next_auth_path() -> Path:
    AUTH_DIR.mkdir(exist_ok=True)
    nums = [
        int(m.group(1))
        for p in AUTH_DIR.glob("google_auth_*.json")
        for m in [re.match(r"google_auth_(\d+)\.json$", p.name)]
        if m
    ]
    return AUTH_DIR / f"google_auth_{max(nums, default=0) + 1}.json"


async def main_async() -> int:
    config = load_config()
    config["browser"]["headless"] = False
    config["browser"]["stable_user_agent"] = True
    scraper = GoogleMapsScraper(config=config)
    await scraper.start_browser()
    try:
        await scraper.page.goto(
            "https://accounts.google.com", wait_until="domcontentloaded", timeout=45000
        )
        input("Log in to the Google account in the browser window, then press Enter here...")

        await scraper.page.goto(
            "https://www.google.com/maps", wait_until="domcontentloaded", timeout=45000
        )
        await asyncio.sleep(3)
        if await scraper.is_signed_out():
            print("Maps still shows 'Sign in' — not saving. Log in fully, then re-run.")
            return 1

        out_path = _next_auth_path()
        await scraper.context.storage_state(path=str(out_path))
        print(f"Saved: {out_path}")
        return 0
    finally:
        await scraper.close_browser()


def main() -> int:
    return asyncio.run(main_async())


if __name__ == "__main__":
    sys.exit(main())
