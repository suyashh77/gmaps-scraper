# Handoff: Google Maps review scraper on forrester (2026-10-05)

You're picking up work on a Google Maps review scraper. This file records what was done in the previous session, the current state, and what's still open. The attached files are the current versions of everything that was changed or added.

## Environment

- **Host:** `forrester.ie.ncsu.edu`, user `scsapre`, headless Linux with no display. The user connects through VS Code Remote-SSH.
- **Project:** `/home/scsapre/review_kit`. Python venv at `.venv/`, Playwright 1.63 using Playwright's bundled Chromium (Google Chrome isn't installed). `Xvfb`/`xvfb-run` are available; `sqlite3` CLI is **not** installed, so use Python's `sqlite3` module.
- **Machine ID:** `9b6a55`. There's no git repo.
- **Batches:** each batch is a SQLite DB in `batches/` (e.g. `batches/dewey8.db`). `collect.py` copies every `batches/*.db` into `results/<name>_9b6a55_<timestamp>.db`. The copies in `results/` are snapshots, never the live DB.
- **Run a batch:** `run_continuous.py --batch <name>.db`. It runs `python -m linux_scraper --db ...` with 2 workers and 3 Google accounts (`auth/google_auth_{1,2,3}.json`).

### Batch DB essentials

- **`stores.status`:** one of `pending`, `in_progress`, `completed`, `failed`, `skipped`. A CHECK constraint enforces this; there is no `closed` status. Closed businesses are stored as `skipped` with `error_message='Permanently/temporarily closed'`.
- **Claiming:** a worker claims a store when `status='pending' AND attempts < 4` (`retry.max_retries = 4` in `linux_scraper/config.py`).
- **Completion rule** (`scraper.scrape_single_store`): a store is complete when `master_reviews + <rows in reviews for store>` reaches `min(1500, target_reviews)`. Measure a store's shortfall the same way: `min(1500,target) - master_reviews - COUNT(reviews)`.
- **Dedup:** `reviews` has `UNIQUE(store_id, review_id)` and `known_review_keys` holds master keys, so rescraping a store never duplicates reviews.
- **Resume state:** `stores.last_sort_order` and `stores.last_review_id`.

## Problem found and fixed: Google sessions were signed out

**Symptom:** many stores stalled at exactly about 200 reviews and failed after 4 attempts. The logs showed `AUTH SIGNED OUT` thousands of times, and "Signed out — skipping Sort click". While signed out, Maps opens a sign-in modal instead of the Sort menu, so only the first ~200 reviews load.

**Root cause:** the auth files were created on another computer on 2026-09-29 and copied here. Each one was signed out on its first use on this PC, about 6 minutes after it was saved. Two things in the code made this worse:
1. `start_browser` picked a random Windows/Mac Chrome 134/135 user agent on every launch, while the browser is actually Linux Chromium 153.
2. The scraper never saved the cookies Google rotates during a session; every launch replayed the original snapshot.

### Fix, part 1: code changes (attached)

**`linux_scraper/scraper.py`** (full file attached as `scraper.py`):
- **Stable user agent:** new `_session_user_agent()` builds the browser's real UA from `self.browser.version`, e.g. `Mozilla/5.0 (X11; Linux x86_64) ... Chrome/153.0.0.0 ...`. `start_browser` uses it whenever an auth file is loaded or `config["browser"]["stable_user_agent"]` is set. Sessions without auth still use the random pool.
- **Cookie writeback:** new `save_session()` writes `context.storage_state()` back to `self.current_auth_file`, atomically through a tmp file plus `os.replace`. `close_browser()` calls it first. It's skipped if `self.signed_out` is set or the jar has no `__Secure-1PSID` for google.com, so a dead session never overwrites a good file.
- **Extra launch args:** `launch_args += config["browser"].get("extra_args", [])`, which the remote-login helper uses to open a DevTools port.

**`make_auth.py`:** sets `config["browser"]["stable_user_agent"] = True`.

**New: `make_auth_remote.py`.** Logs in on this headless PC:
`xvfb-run -a .venv/bin/python make_auth_remote.py --slot N --port 9222 [--timeout-min 30]`
It launches a headed Chromium on the virtual display with the same settings and UA as the scraper, and opens `--remote-debugging-port` on 127.0.0.1. It polls until Google Maps shows the account signed in, then saves `auth/google_auth_<N>.json`. No keypress is needed.

**New: `relogin_then_dewey8.sh`.** Starts 3 login browsers at once (slots 1–3, ports 9222–9224, 240-minute timeout). When all three finish, it runs `check_auth.py`. Only if all three report SIGNED IN does it start:
`xvfb-run -a .venv/bin/python run_continuous.py --batch dewey8.db --no-headless`
The scrape runs headed under Xvfb so it's the same browser Google saw at login. The script was launched detached (`setsid nohup ... > logs/relogin_then_dewey8.log`).

The old (dead) auth files are backed up in `auth/old_20261005/`. **Never put `auth/` in a handoff or anywhere shared:** the files are live session cookies.

### Fix, part 2: how the user logs in (a human step)

Logging in needs the user, for the password and 2FA. These steps worked:
1. In VS Code's **PORTS** tab, forward 9222, 9223 and 9224.
2. In the user's local Chrome, go to `chrome://inspect/#devices`, check **Discover network targets**, then **Configure…** and add `localhost:9222`, `localhost:9223` and `localhost:9224`.
3. Under Remote Target, each port lists several entries. Click **inspect** on the **first** "Sign in - Google Accounts" entry and ignore the youtube CheckConnection and Omnibox entries. Turn on the screencast (phone/monitor icon) if the page isn't visible. Log in, using one different account per port.
4. The entry disappears once the session is saved.

**Fallbacks** if Remote Target stays empty:
- Test forwarding: open `http://localhost:9222/json/version` locally.
- Make the tunnel by hand from the user's own computer: `ssh -N -L 9222:127.0.0.1:9222 -L 9223:127.0.0.1:9223 -L 9224:127.0.0.1:9224 scsapre@forrester.ie.ncsu.edu`
- Open a page directly: `devtools://devtools/bundled/inspector.html?ws=localhost:9222/devtools/page/<id>`, where the id comes from `/json/list`.

**Result (2026-10-05 11:25):**
- All 3 accounts were SIGNED IN, and dewey8 started.
- The scraper applied "Sort by newest" on its first store, which never worked before.
- It collected about 30 reviews every 25 seconds.
- 0 `AUTH SIGNED OUT` by 11:58.

## Database operations done in the previous session

1. **dewey1 (2026-10-01):**
   - **Rule:** stores within 10 reviews of target (shortfall < 11) were to be marked `completed`; the rest requeued. None qualified (the smallest gap was 26).
   - **Change:** all 203 failed stores were set to `status='pending', attempts=0, worker_id=NULL, error_message=NULL`, with resume state kept.
   - **Backup:** `batches/dewey1.pre_requeue_20261001.db`
2. **dewey6 (2026-10-04):**
   - **Change:** all 58 failed stores were set to `pending, attempts=0`, with `error_message`, `last_sort_order`, `last_review_id` and `last_attempt` cleared. Reviews were kept. The 22 closed stores stayed `skipped`.
   - **Backup:** `batches/dewey6.pre_requeue_20261004.db`
   - **Later:** dewey6 was **run again on 2026-10-04 between 12:26 and 14:55 while the accounts were still signed out**, and 57 of the 58 failed again. It needs another requeue, using the same SQL as above.
3. **dewey8:** moved from the project root to `batches/dewey8.db` so `collect.py` picks it up. It started with 308 pending stores.

## State as of 2026-10-05 11:58

| Batch | completed | failed | pending | in_progress | skipped | reviews |
|---|---|---|---|---|---|---|
| dewey8 (running now) | 4 | 15 | 269 | 2 | 18 | 1,619 |
| dewey6 | 194 | 57 | 0 | 0 | 22 | 76,906 |
| dewey1 | 925 | 0 | 202 | 1 (stale) | 3 | 94,672 |

Some failures are expected and aren't auth problems. Stores whose log shows "Business: … | Reviews: 0" and "No Reviews tab found" with `live=0` have no reviews on Google; their target of 200 is a placeholder. They use their 4 attempts quickly and end up `failed`. In dewey8 most of the 15 failures are this kind. In dewey6 about 17 of the 57 are.

## Open items

1. **dewey8:** watch `logs/relogin_then_dewey8.log`, either for completion or for `AUTH SIGNED OUT` (or stores stalling at exactly 200). If sessions die, redo the remote login, run `check_auth.py`, then restart.
2. **dewey6:** requeue its 57 failed stores again and run it with the same setup (`xvfb-run -a .venv/bin/python run_continuous.py --batch dewey6.db --no-headless`) after dewey8, or after confirming one batch per machine is the rule. The README says to run only one batch per machine/IP.
3. **dewey1:** still has 202 pending stores and 1 stale `in_progress` store. The scraper resets `in_progress` stores on startup.
4. **Not yet proven:** that sessions stay signed in over a multi-day run with cookie writeback.
5. **Before any run:** run `xvfb-run -a .venv/bin/python check_auth.py`. It prints SIGNED IN or SIGNED OUT per account. Note that `check_auth.py` now writes refreshed cookies back too, through `close_browser`.

## Working notes

- Read the live DBs in `batches/`; treat the copies in `results/` as read-only snapshots.
- Back up a DB before changing it in bulk. The scraper uses WAL, so copy it with `sqlite3.Connection.backup`, not `cp`, when the DB may be open.
- Don't search the whole filesystem with `find /`: network mounts hang it. Search inside `~` with a small `-maxdepth`.
- In a `pgrep -f` wait loop, the pattern can match the loop's own bash command line, and the loop never exits.
